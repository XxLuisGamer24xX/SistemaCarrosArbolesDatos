package controler;

import arbolesBinarios.Arbol;
import arbolesBinarios.Nodo;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class BuscarC {
	Arbol arbol;
    public Arbol getArbol() {
		return arbol;
	}
	public void setArbol(Arbol arbol) {
		this.arbol = arbol;
	}
    @FXML
    private Button btAgregar;

    @FXML
    private Label lbUser;

    @FXML
    private Label lbUser1;

    @FXML
    private Label lbUser2;

    @FXML
    private Label lbUser21;

    @FXML
    private Label lbUser22;

    @FXML
    private Label lbUser221;

    @FXML
    private Label mensajeError;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtColor;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtModelo;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtPrecio;

    @FXML
    void clickAgregar(MouseEvent event) {
    	String cedula=txtId.getText();
    	Integer cedulaInteger = Integer.valueOf(cedula);
    	if(arbol.buscar(arbol.getRaiz(),cedulaInteger)==null) {
    		txtNombre.setText("");   
    		txtApellido.setText("");   
    		txtColor.setText("");   
    		txtModelo.setText("");  
    		txtPrecio.setText("");  
    		mensajeError.setText(cedula+" no existe");
    	}
    	else {    		
    		mensajeError.setText("Se encontró con exito");    		
    		Nodo personaEncontrada;
    		personaEncontrada=arbol.buscar(arbol.getRaiz(),cedulaInteger); 		
    		String nombre=personaEncontrada.getNombre();
    		String apellido=personaEncontrada.getApellido();
    		String color=personaEncontrada.getColor();
    		String estado=personaEncontrada.getModelo();
    		Double precio=personaEncontrada.getPrecio();    		
    		//muestro en las cajas de texto  
    		txtNombre.setText(nombre);   
    		txtApellido.setText(apellido);   
    		txtColor.setText(color);   
    		txtModelo.setText(estado); 
    		txtPrecio.setText(precio+"");;
    	}
    }
    @FXML
    void pasarAgregar(MouseEvent event) {
    	btAgregar.setStyle("-fx-background-color: #C21010;");
    	btAgregar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
    	btAgregar.setStyle("-fx-background-color: black;");
    	btAgregar.setTextFill(Color.WHITE);
    }

}
