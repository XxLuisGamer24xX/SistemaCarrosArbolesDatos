package controler;

import arbolesBinarios.Arbol;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class EliminarC {
	Arbol arbol;
    public Arbol getArbol() {
		return arbol;
	}
	public void setArbol(Arbol arbol) {
		this.arbol = arbol;
	}
    @FXML
    private Button btAgregar;

    @FXML
    private Label lbUser;

    @FXML
    private Label lbUser1;

    @FXML
    private Label lbUser2;

    @FXML
    private Label lbUser21;

    @FXML
    private Label lbUser22;

    @FXML
    private Label lbUser221;

    @FXML
    private Label mensajeError;

    @FXML
    private TextField txtApellido;

    @FXML
    private TextField txtColor;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtModelo;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtPrecio;

    @FXML
    void clickAgregar(MouseEvent event) {
    	String cedula=txtId.getText();
    	Integer cedulaInteger = Integer.valueOf(cedula);
    	boolean eliminado = arbol.eliminarNodoPorCedula(cedulaInteger);
    	if (eliminado) {
    		mensajeError.setText("Se eliminó correctamente");
    	}
    	else {
    		mensajeError.setText("No existe esa cédula");
    	}    	
    }

    @FXML
    void pasarAgregar(MouseEvent event) {
    	btAgregar.setStyle("-fx-background-color: #C21010;");
    	btAgregar.setTextFill(Color.WHITE);
    }
    @FXML
    void quitarAgregar(MouseEvent event) {
    	btAgregar.setStyle("-fx-background-color: black;");
    	btAgregar.setTextFill(Color.WHITE);
    }

}
